Building Cloudcoin
================

See doc/build-*.md for instructions on building the various
elements of the Cloudcoin Core reference implementation of Cloudcoin.
